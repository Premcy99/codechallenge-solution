from django.shortcuts import render
import json
import pandas as pd


def acc_details(request):
    with open('report.txt') as f:
        jsonData = json.loads(f.read())
        df = pd.read_json(jsonData)
        data_dict = df.to_dict()
        final=data_dict["MergeCreditReport"]["Accounts"]["Collection"]
        return render(request,'page.html',{'res':final})

